#ifdef VIRTIOCON

#include "libmetal/lib/system/generic/generic_init.c"

#endif /* VIRTIOCON */
