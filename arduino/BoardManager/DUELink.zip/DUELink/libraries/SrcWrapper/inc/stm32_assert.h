/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef STM32_ASSERT_H
#define STM32_ASSERT_H

/*
 * Header file required by LL layer but as USE_HAL_DRIVER is defined
 * assert definitions are provided by stm32yyxx_hal_conf_default
 */

#endif /* STM32_ASSERT_H */
